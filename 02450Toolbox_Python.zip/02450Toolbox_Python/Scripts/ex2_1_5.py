# exercise 2.2.4
# (requires data structures from ex. 2.2.1 and 2.2.3)
from ex2_1_1 import *

print V[:,2].T
# projection of water class onto the 2nd principal component.
print (Y[y.A.ravel()==4,:] * V[:,2]).T
